
package deliveryapp;

import LoginForm.LoginJFrame;

public class DeliveryApp {

   
    public static void main(String[] args) {
        
        LoginJFrame LoginObj = new LoginJFrame();
        LoginObj.show();
    }
    
}
